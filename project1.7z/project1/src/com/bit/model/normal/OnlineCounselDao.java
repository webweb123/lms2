package com.bit.model.normal;

public class OnlineCounselDao {
	OnlineCounselDto ex = new OnlineCounselDto();
}
