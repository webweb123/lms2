package com.bit.model.normal;

import java.sql.Date;

public class recruitOrderDto {//�����Ƿ�
	private int idx;
	private String companyName;//ȸ���̸�
	private String homepage;//Ȩ������ �ּ�
	private String position;//����
	private int handPhone;//�ڵ���
	private String field;//�����о�
	private String local;//�ٹ���
	private String rsl;//�䱸���
	private String gender;//����
	private int year;//���
	private int people;//ä���ο�
	private int regisNum;//����� ��Ϲ�ȣ
	private String name;//����
	private int phone;//����ó
	private String email;//�̸���
	private String task;//������
	private int pay;//����
	private String background;//�з�
	private int age;//����
	private String neceDocu;//�ʿ伭��
	private Date eDay;//���������� 
	private String content;//����
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getHomepage() {
		return homepage;
	}
	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public int getHandPhone() {
		return handPhone;
	}
	public void setHandPhone(int handPhone) {
		this.handPhone = handPhone;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public String getRsl() {
		return rsl;
	}
	public void setRsl(String rsl) {
		this.rsl = rsl;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getPeople() {
		return people;
	}
	public void setPeople(int people) {
		this.people = people;
	}
	public int getRegisNum() {
		return regisNum;
	}
	public void setRegisNum(int regisNum) {
		this.regisNum = regisNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public int getPay() {
		return pay;
	}
	public void setPay(int pay) {
		this.pay = pay;
	}
	public String getBackground() {
		return background;
	}
	public void setBackground(String background) {
		this.background = background;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getNeceDocu() {
		return neceDocu;
	}
	public void setNeceDocu(String neceDocu) {
		this.neceDocu = neceDocu;
	}
	public Date geteDay() {
		return eDay;
	}
	public void seteDay(Date eDay) {
		this.eDay = eDay;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	
	
	
}
