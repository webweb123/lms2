package com.bit.model.normal;

public class FaqDao {
	FaqDto ex = new FaqDto();
}
