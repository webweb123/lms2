package com.bit.model.normal;

public class AfterSucBbsDto {//�����Ȳ�Խ���
	private int idx;//��ȣ
	private String name;//�̸�
	private String eduCurri;//��������
	private int company;//�����ü��
	private int field;//����о�
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEduCurri() {
		return eduCurri;
	}
	public void setEduCurri(String eduCurri) {
		this.eduCurri = eduCurri;
	}
	public int getCompany() {
		return company;
	}
	public void setCompany(int company) {
		this.company = company;
	}
	public int getField() {
		return field;
	}
	public void setField(int field) {
		this.field = field;
	}
	
	
}
