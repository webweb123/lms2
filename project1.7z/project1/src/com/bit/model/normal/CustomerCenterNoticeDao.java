package com.bit.model.normal;

public class CustomerCenterNoticeDao {
	CustomerCenterNoticeDto ex = new CustomerCenterNoticeDto();
}
