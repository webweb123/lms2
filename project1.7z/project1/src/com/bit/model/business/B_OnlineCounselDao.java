package com.bit.model.business;

public class B_OnlineCounselDao {
	B_OnlineCounselDto ex = new B_OnlineCounselDto();
}
