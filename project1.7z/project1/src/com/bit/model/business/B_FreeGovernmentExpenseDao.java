package com.bit.model.business;

public class B_FreeGovernmentExpenseDao {
	B_FreeGovernmentExpenseDto ex = new B_FreeGovernmentExpenseDto();
}
