package com.bit.model.business;

public class B_CustomerCenterNoticeDao {
	B_CustomerCenterNoticeDto ex = new B_CustomerCenterNoticeDto();
}
