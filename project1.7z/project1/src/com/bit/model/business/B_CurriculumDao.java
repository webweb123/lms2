package com.bit.model.business;

public class B_CurriculumDao {
	B_CurriculumDto ex = new B_CurriculumDto();
}
