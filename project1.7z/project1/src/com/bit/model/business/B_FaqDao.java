package com.bit.model.business;

public class B_FaqDao {
	B_FaqDto ex = new B_FaqDto();
}
