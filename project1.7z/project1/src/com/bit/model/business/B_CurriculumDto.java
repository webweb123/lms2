package com.bit.model.business;

public class B_CurriculumDto {

}
