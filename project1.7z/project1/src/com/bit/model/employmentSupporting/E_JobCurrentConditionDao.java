package com.bit.model.employmentSupporting;

public class E_JobCurrentConditionDao {
	E_JobCurrentConditionDto ex = new E_JobCurrentConditionDto();
}
