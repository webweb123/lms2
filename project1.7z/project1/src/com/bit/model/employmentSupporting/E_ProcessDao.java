package com.bit.model.employmentSupporting;

public class E_ProcessDao {
	E_ProcessDto ex = new E_ProcessDto();
}
