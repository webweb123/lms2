package com.bit.model.employmentSupporting;

public class E_RecuitOrderDto {

}
