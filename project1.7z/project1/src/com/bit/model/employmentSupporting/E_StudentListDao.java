package com.bit.model.employmentSupporting;

public class E_StudentListDao {
	E_StudentListDto ex = new E_StudentListDto();
}
