package com.bit.model.employmentSupporting;

public class E_RecuitOrderDao {
	E_RecuitOrderDto ex = new E_RecuitOrderDto();
}
