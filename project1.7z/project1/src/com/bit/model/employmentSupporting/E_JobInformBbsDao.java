package com.bit.model.employmentSupporting;

public class E_JobInformBbsDao {
	E_JobInformBbsDto ex = new E_JobInformBbsDto();
}
