package com.bit.model;

public class Jop_cs_Dto {
	private int idx;
	private int emp_code;
	private String id;
	private String eduCurri;
	private String company;
	private String field;
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public int getEmp_code() {
		return emp_code;
	}
	public void setEmp_code(int emp_code) {
		this.emp_code = emp_code;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEduCurri() {
		return eduCurri;
	}
	public void setEduCurri(String eduCurri) {
		this.eduCurri = eduCurri;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	
	
}
