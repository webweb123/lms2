package com.bit.model.administration;

public class A_FreeBbsDao {
	A_FreeBbsDto ex = new A_FreeBbsDto();
}
