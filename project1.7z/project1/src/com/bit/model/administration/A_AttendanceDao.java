package com.bit.model.administration;

public class A_AttendanceDao {
	A_AttendanceDto ex = new A_AttendanceDto();
}
