package com.bit.model.administration;

public class A_StudentListDto {

}
