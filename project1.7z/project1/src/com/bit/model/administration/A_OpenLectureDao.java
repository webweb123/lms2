package com.bit.model.administration;

public class A_OpenLectureDao {
	A_OpenLectureDto ex = new A_OpenLectureDto();
}
