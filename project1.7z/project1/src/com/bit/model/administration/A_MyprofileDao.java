package com.bit.model.administration;

public class A_MyprofileDao {
	A_MyprofileDto ex = new A_MyprofileDto();
}
