package com.bit.model.administration;

public class A_StudentNoticeDao {
	A_StudentNoticeDto ex = new A_StudentNoticeDto();
}
