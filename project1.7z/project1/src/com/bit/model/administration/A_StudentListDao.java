package com.bit.model.administration;

public class A_StudentListDao {
	A_StudentListDto ex = new A_StudentListDto();
}
