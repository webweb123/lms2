package com.bit.model.administration;

public class A_RegisterDao {
	A_RegisterDto ex = new A_RegisterDto();
}
