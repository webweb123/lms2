package com.bit.model.administration;

public class A_gradeDao {
	A_gradeDto ex = new A_gradeDto();
}
