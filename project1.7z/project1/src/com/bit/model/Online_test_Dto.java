package com.bit.model;

public class Online_test_Dto {
	private int qnum;
	private String question;
	private String example;
	private int answer;
	private int class_room;
	public int getQnum() {
		return qnum;
	}
	public void setQnum(int qnum) {
		this.qnum = qnum;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getExample() {
		return example;
	}
	public void setExample(String example) {
		this.example = example;
	}
	public int getAnswer() {
		return answer;
	}
	public void setAnswer(int answer) {
		this.answer = answer;
	}
	public int getClass_room() {
		return class_room;
	}
	public void setClass_room(int class_room) {
		this.class_room = class_room;
	}
	
}
